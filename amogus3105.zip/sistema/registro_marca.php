<?php include_once "includes/header.php";
$mensaje = "";
//=================================== BUSCAR ===================================
//ACORDATE, CREAR UN NUEVO RES, JUNTO CON UN NUEVO TBODY. ASI TRAES VARIAS TABLAS AL MISMO TIEMPO
//PROBALO MANANA, A DORMIR, CHAU.
if(isset($_POST['bttn_buscar'])){
  $aux = strtolower(trim($_POST['palabra_buscar']));
  var_dump($v);
  return;
  //$res = marca::buscar_marcas($aux);
}else{
  $res = marca::traer_marcas_habilitadas();
} 
//=================================== ACTUALIZAR ===================================
foreach($_POST as $key=>$value){
  $a = strstr($key, 'gua');
  $b = (substr($a, 0, 3)=='gua')? true:false;
  if($b){
    if(trim($_POST['nombre2']) == "")
    {
        $mensaje = "No deje espacios en blanco.";
    }else{
      $aux = strtolower(trim($_POST['nombre2']));
      $nombres = marca::traer_nombre_marcas();
      foreach($nombres as  $key=>$datos2){
        if($aux == $datos2->nombre){
            $mensaje = "La marca ya existe";
        }
      }
      if($mensaje != "La marca ya existe"){
        $brand = new marca;
        $nombre2 = ucwords(strtolower($_POST['nombre2']));
        $nombre2 = preg_replace('/\s+/', ' ', $nombre2);
        $nombre2 = ltrim(rtrim($nombre2));
        $brand->id = trim($_POST['id2']);
        $brand->nombre = $nombre2;
        $brand->update();
        $mensaje = "Datos Actualizados";
      }else{
        $mensaje = "La marca ya existe";
      }
    }
  }else{
    $a = strstr($key, 'del');
    $b = (substr($a, 0, 3) == 'del')? true:false;
    if($b){
      $brand = new marca();
      $brand->id = trim($_POST['id2']);
      $brand->delete_logico();
      $mensaje = "Datos Eliminados";
    }
  }
  $a = strstr($key, 'res');
  $b = (substr($a, 0, 3)=='res')? true:false;
  if($b){
    $brand = new marca();
    $brand->id = trim($_POST['id2']);
    $brand->restaurar();
    $mensaje = "Datos restaurados";
  }
}
?>
<!-- Begin Page Content -->
<div class="container-fluid">
  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800 text-light">Registrar Marca</h1>
  </div>
  <!-- Content Row -->
  <div class="row">
    <div class="col-lg-6 m-auto">
      <div class="card">
        <div class="card-header bg-primary text-white font-weight-bold">
          Nueva Marca
        </div>
        <div id="mcform" class="card-body">
          <form id="frm_RegistrarMarca" action="" method="post" autocomplete="off">
            <label id="lblMensaje" class="text-warning h3"><?php echo $mensaje; ?></label>
            <div class="form-group">
              <label for="marca" class="text-light">Nombre</label>
              <input type="text" onkeypress="return /[a-z ]/i.test(event.key)" placeholder="Ingrese nombre de la marca"
                name="nombre" id="nombre" class="form-control" required>
            </div>
            <br>
            <button type="submit" id="bttn_RegistrarMarca" name="registrar_marca"
              class="btn btn-primary text-white font-weight-bold">Guardar Marca</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<!--========================MOSTRAR=========================-->
<h4 id="h4_mensaje" class="h3 text-warning"></h4>
<!--NO BORRAR, REPARA EL buscador()
  PARA LOS QUE NO LLEVAN EL <h4> con id="h4_mensaje" en sus paginas-->
<div class="container-fluid">
  <hr>
  <!-- Page Heading -->
  <?php 
    $v1 = marca::contar_marcas_habilitadas(); 
    $v2 = marca::contar_marcas_deshabilitadas();
  ?>
  <?php buscador($v1, $v2);?>
  <!-- Page Body -->
  <div class="row">
    <div class="col-lg-12">
      <div class="table-responsive">
        <table class="table table-striped table-bordered" id="mctable">
          <thead class="thead-dark">
            <tr>
              <th>IDaaaaaaaaaaaaaa</th>
              <th>NOMBRE</th>
            </tr>
          </thead>
          <!--=====================================opt_Available=====================================-->
          <tbody id="tb_availables">
            <?php
              $i = 0;
              for($i=0; $i<count($res); $i=$i+1){
              ?><tr>
              <form method="POST">
                <td id="mycell"><input class="text-light" readonly type="text"
                    <?= "id='id{$i}' value='{$res[$i]->id}'" ?> name="id2"></input></td>
                <td><input class="form-control text-white" onkeypress="return /[a-z ]/i.test(event.key)" name="nombre2"
                    type="text" <?= "id='nombre{$i}' 
                    value='{$res[$i]->nombre}'"?> disabled />
                </td>
                <?php bttnguardar_borrar($i);?>
                <?php modal($i);?>
                <td><input class="btn btn-success" <?= "id='edit{$i}'"?> name="submit" type="button"
                    onclick="enabletodomc(this)" value="Editar"></td>
              </form>
            </tr>
            <?php
              }
            ?>
          </tbody>
          <!--=====================================opt_Unavailable=====================================-->
          <tbody id="tb_unavailables" hidden>
            <?php 
              $res2 = marca::traer_marcas_deshabilitadas();
              $z = 0;
              for($z=0; $z<count($res2); $z=$z+1){
              ?><tr>
              <form method="POST">
                <td id="mycell"><input class="text-light" readonly type="text"
                    <?= "id='id{$z}' value='{$res2[$z]->id}'" ?> name="id2"></input></td>
                <td><input class="form-control text-white" name="nombre2" type="text" <?= "id='nombre{$z}' 
                    value='{$res2[$z]->nombre}'"?> disabled />
                </td>
                <?php bttnrestaurar($z);?>
              </form>
            </tr>
            <?php
              }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script src="vendor/jquery/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
  $('#bttn_RegistrarMarca').click(function() {
    var datos = $('#frm_RegistrarMarca').serialize();
    $.ajax({ //TE ODIO AJAX
      type: "POST",
      url: "negocio/Reg_Marca.php",
      data: datos,
      success: function(res) {
        $('#lblMensaje').text(res);
        if ($('#lblMensaje').text() == "Se registro correctamente") {
          document.getElementById("nombre").value = "";
        }
      }
    });
    return false;
  });
});
</script>
<!-- /.container-fluid -->
<?php include_once "includes/footer.php"; ?>
