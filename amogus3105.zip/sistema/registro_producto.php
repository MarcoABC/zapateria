<?php include_once "includes/header.php";
$mensaje = "";
if(isset($_POST['registrar_producto'])){
    $product = new producto;
    $product->nombre = trim($_POST['nombre']);
    $nombres = producto::traer_nombre_productos();
    foreach($nombres as  $key=>$datos2){
        if(trim($_POST['nombre']) == $datos2->nombre){
            $mensaje = "El producto ya existe";
        }
    }
    if($mensaje != "La categoria ya existe"){
        //$mensaje = "";
        if( trim($_POST['nombre']) == ""        || trim($_POST['color']) == ""          ||
          trim($_POST['talla']) == ""         || trim($_POST['precio']) == ""         ||
          trim($_POST['id_marca']) == ""      || trim($_POST['id_categoria']) == ""   ||
          trim($_POST['id_proveedor']) == "" ){
          $mensaje = "No deje espacios en blanco.";
        }else{
          $product->nombre        = trim($_POST['nombre']);
          $product->color         = trim($_POST['color']);
          $product->talla         = trim($_POST['talla']);
          $product->precio        = trim($_POST['precio']);
          $product->id_marca      = trim($_POST['id_marca']);
          $product->id_categoria  = trim($_POST['id_categoria']);
          $product->id_proveedor  = trim($_POST['id_proveedor']);
          $product->create();
          $mensaje = "Se registro correctamente";
          unset($_POST);
        }
    }else{
        $mensaje = "El producto ya existe";
    }
}
?>
 <!-- Begin Page Content -->
 <div class="container-fluid">
   <!-- Page Heading -->
   <div class="d-sm-flex align-items-center justify-content-between mb-4">
     <h1 class="h3 mb-0 text-gray-800 text-light">Registrar Producto</h1>
     <a href="lista_productos.php" class="btn btn-primary text-white font-weight-bold">Listar</a>
   </div>
   <!-- Content Row -->
   <div class="row">
     <div class="col-lg-6 m-auto">
       <div class="card">
         <div class="card-header bg-primary text-white font-weight-bold">
           Nuevo Producto
         </div>
         <div class="card-body">
           <form action="" method="post" autocomplete="off">
             <label class="text-warning h3"><?php echo $mensaje; ?></label>
             <div class="form-group">
               <label for="nombre" class="text-light">Nombre</label>
               <input type="text" placeholder="Nombre del producto" name="nombre" id="nombre" class="form-control" required>
             </div>
             <div class="form-group">
               <label class="text-light">Color</label>
               <select id="color" name="color" class="form-control">
                <?php 
                  //Carga aqui los colores ?  
                ?>
               </select>
             </div>
             <div class="form-group">
               <label for="talla" class="text-light">Talla</label>
               <input type="text" placeholder="Ingrese la talla" class="form-control" name="talla" id="talla" required>
             </div>
             <div class="form-group">
               <label for="precio" class="text-light">Precio</label>
               <input type="text" placeholder="Ingrese precio" class="form-control" name="precio" id="precio" required>
             </div>
             <div class="form-group">
               <label class="text-light">Proveedor</label>
               <select id="proveedor" name="id_proveedor" class="form-control">
                 <?php
                  //Carga aqui a los proveedores
                  ?>
               </select>
             </div>
             <div class="form-group">
               <label class="text-light">Categoría</label>
               <select id="categoria" name="id_categoria" class="form-control">
                 <?php
                  //Carga aqui a los categoria
                  ?>
               </select>
             </div>
             <div class="form-group">
               <label class="text-light">Marca</label>
               <select id="marca" name="id_marca" class="form-control">
                 <?php
                  //Carga aqui a los marca
                  ?>
               </select>
             </div>
             <br>
             <button type="submit" name="registrar_producto" class="btn btn-primary">Guardar Producto</button>
           </form>
         </div>
       </div>
     </div>
   </div>
 </div>
 <!-- /.container-fluid -->
<!-- ======================================ESTILO====================================== -->

<style>
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
    }
    input[type=number] {
    -moz-appearance: textfield;
    }
</style>

 <?php include_once "includes/footer.php"; ?>
