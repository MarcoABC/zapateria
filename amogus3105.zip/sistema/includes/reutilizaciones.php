<?php

function modal($i){
    echo '
    <div class="modal fade" id=myModal'.$i.' role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">¿Seguro que deseas eliminar este dato? 😮</h4>
                </div>
                <div class="modal-body">
                    <input class="btn btn-danger" type="submit"   name="delete" id=del'.$i.' value="Sí, Eliminalo!">
                    <input class="btn btn-info"   type="button"   data-dismiss="modal" value="No">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                </div>
            </div>
        </div>
    </div>';
}

function bttnguardar_borrar($i){
    echo '
        <td class="align-middle"><input class="btn btn-info"   type="submit" id=save'.$i.' name="guardar"  value="Guardar"   disabled></td>
        <td class="align-middle"><input class="btn btn-danger" type="button" id=bdele'.$i.' data-target=#myModal'.$i.' value="Eliminar" data-toggle="modal" disabled></td> 
    ';
}

function bttnrestaurar($i){
    echo '
        <td class="align-middle"><input class="btn btn-info"   type="submit" id=rest'.$i.' name="restaurar"  value="Restaurar"></td>
    ';
}

function buscador($v1, $v2){
    echo '
    <h5 class="text-light">Filtrar por:</h5>
    <div class="row">
        <div class="col">
            <select class="form-control bg-dark text-light" name="find_options">
                <option value="1" id="opt_Available">Habilitados</option>
                <option value="1" id="opt_Unavailable">Deshabilitados</option>
            </select>
            <button class="mt-3 mb-3 btn btn-success" onclick="buscar_deshabilitados()">
                Buscar
            </button>
            <h5 hidden id="lbl_Available" class="text-warning">Mostrando Habilitados: '.$v1.'</h5>
            <h5 hidden id="lbl_Unavailable" class="text-warning">Mostrando Deshabilitados: '.$v2.'</h5>
        </div>
        <div class="col">
            <form method="post" action="">
                <div class="input-group mb-4">
                    <input name="palabra_buscar" type="search" placeholder="¿Qué estás buscando?" aria-describedby="button-addon5" class="bg-dark text-light form-control">
                    <div class="input-group-append">
                        <button name="bttn_buscar" id="button-addon5" type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                    </div>
                </div>
            </form>        
        </div>
    </div>
    ';
}

/*
function buscador(){
    echo '
    <h5 class="text-light">Filtrar por:</h5>
    <div class="row">
        <div class="c