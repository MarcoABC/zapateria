<?php
class producto extends db_object{
    public static $db_tabla = "tproducto"; //Variable para manejar la tabla
    public static $db_campos_tabla = array('cid', 'nombre', 'apellido_paterno', 'apellido_materno', 'fecha_nacimiento', 'telefono', 'email'); // Referencia a los campos de la tabla
    public $id;
    public $nombre;
    public $color;
    public $talla;
    public $precio;
    public $id_marca;
    public $id_categoria;
    public $id_proveedor;
    
    //CRUD
    public function create(){
        global $database;
        $propiedades = $this->propiedades();
        $sql = "INSERT INTO ".self::$db_tabla."(".implode(", ", array_keys($propiedades)).")";
        $sql .= " VALUES ('".implode("','", array_values($propiedades))."')";
        if($database->consulta($sql)){
            return true;
        }else{
            return false;
        }
    }

    public static function traer_nombre_productos(){
        return static::query("SELECT nombre FROM ".static::$db_tabla);    
    }
    
    public static function contar_productos(){
        $sql = ("SELECT COUNT(id) as id FROM ".static::$db_tabla);
        if($row = static::query($sql)){
            $id = trim($row[0]->id);
            return $id;
        }
    }

}
