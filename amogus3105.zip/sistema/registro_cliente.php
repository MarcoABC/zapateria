<?php include_once "includes/header.php";?>

<!-- Begin Page Content -->
<div class="container-fluid">
  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800 text-light">Registrar Nuevo Cliente</h1>
    <a href="lista_cliente.php" class="btn btn-primary font-weight-bold">Listar</a>
  </div>
  <!-- Content Row -->
  <div class="row">
    <div class="col-lg-6 m-auto">
      <div class="card">
        <div class="card-header bg-primary text-white font-weight-bold">
          Nuevo Cliente
        </div>
        <div class="card-body" id="mcform">
          <form action="" method="post" autocomplete="off" id="frm_reg_cliente">
            <label class="text-warning h3" id="lblMensaje"></label>
            <div class="form-group">
              <label for="ci" class="text-light">CI</label>
              <div class="row">
                <div class="col">
                  <input class="form-control" type="number" placeholder="Ingrese CI" name="ci" id="ci"
                    class="form-control" onkeypress="return /[0-9-]/i.test(event.key)" required>
                </div>
                <div class="col">
                  <select class="bg-dark text-light form-control" name="extension">
                    <option value="SC">SC</option>
                    <option value="CB">CB</option>
                    <option value="LP">LP</option>
                    <option value="TJ">TJ</option>
                    <option value="CH">CH</option>
                    <option value="BE">BE</option>
                    <option value="PD">PD</option>
                    <option value="OR">OR</option>
                    <option value="PT">PT</option>
                    <option value="EX">Extranjero</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="form-group">
              <label for="nombre" class="text-light">Nombre</label>
              <input type="text" onkeypress="return /[a-z ]/i.test(event.key)" class="form-control"
                placeholder="Ingrese Nombre" name="nombre" id="nombre" required>
            </div>
            <div class="form-group">
              <label for="apPaterno" class="text-light">Apellido Paterno</label>
              <input type="text" onkeypress="return /[a-z ]/i.test(event.key)" class="form-control"
                placeholder="Apellido Paterno" name="apPaterno" id="apPaterno" required>
            </div>
            <div class="form-group">
              <label for="apMaterno" class="text-light">Apellido Materno</label>
              <input type="text" onkeypress="return /[a-z ]/i.test(event.key)" class="form-control"
                placeholder="Apellido Materno" name="apMaterno" id="apMaterno" required>
            </div>
            <div class="form-group">
              <label for="telefono" class="text-light">Teléfono</label>
              <input type="number" class="form-control" onkeypress="return /[0-9]/i.test(event.key)"
                placeholder="Teléfono" name="telefono" id="telefono"
                oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
                maxlength="8" />
            </div>
            <br>
            <button type="submit" id="reg_cliente" name="registrar_cliente" class="btn btn-primary"
              onclick="reg_cliente(this)">Guardar
              Cliente</button>
          </form>
        </div>
      </div>
    </div>
  </div>

</div>
<script src="vendor/jquery/jquery.min.js"></script>
<!--HAY Q INCLUIR ESTA WEA SI O SI-->
<script type="text/javascript">
$(document).ready(function() {
  $('#reg_cliente').click(function() { //ID del boton del formulario
    var datos = $('#frm_reg_cliente').serialize(); //ID del formulario
    $.ajax({ //TE ODIO AJAX
      type: "POST",
      url: "negocio/Reg_Cliente.php", //direccion del php q vamos a usar
      data: datos,
      success: function(res) { //echo que devuelve el llamado al php
        $('#lblMensaje').text(res); //asignar la respuesta al l*abel mensaje
        if ($('#lblMensaje').text() == "Se registro correctamente") {
          document.getElementById("ci").value = "";
          document.getElementById("nombre").value = "";
          document.getElementById("apPaterno").value = "";
          document.getElementById("apMaterno").value = "";
          document.getElementById("telefono").value = "";
        }
      }
    });
    return false; //evitar q  se recargue la pinche pagina
  });
});
</script>
<!-- /.container-fluid -->
<?php include_once "includes/footer.php"; ?>