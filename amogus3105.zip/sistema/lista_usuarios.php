﻿<?php include_once "includes/header.php"; 

//=================================== ACTUALIZAR ===================================
foreach($_POST as $key=>$value){
	$a = strstr($key, 'gua');
	$b = (substr($a, 0, 3)=='gua')? true:false;

	if($b){
		if(trim($_POST['ci']) == "" || trim($_POST['nombre']) == "" || trim($_POST['apPaterno']) == "" ||
		trim($_POST['apMaterno']) == "" || trim($_POST['telefono']) == "" || trim($_POST['direccion']) == ""
		)
		{
			$mensaje = "No deje espacios en blanco.";
		}else{
			$aux = trim($_POST['ci']);
			//$cis = persona::traer_ci_entero();
			//foreach($cis as  $key=>$datos2){
			//	if($aux == $datos2->ci){
			//		$mensaje = "El usuario ya existe";
			//	}
			//}
			if($mensaje != "El usuario ya existe"){
				$persona = new persona;
				//Nombre
				$nombre = ucwords(strtolower($_POST['nombre']));
				$nombre = preg_replace('/\s+/', ' ', $nombre);
				$nombre = ltrim(rtrim($nombre));
				//ApellidoP
				$apPaterno = ucwords(strtolower($_POST['apPaterno']));
				$apPaterno = preg_replace('/\s+/', ' ', $apPaterno);
				$apPaterno = ltrim(rtrim($apPaterno));
				//ApellidoM
				$apMaterno = ucwords(strtolower($_POST['apMaterno']));
				$apMaterno = preg_replace('/\s+/', ' ', $apMaterno);
				$apMaterno = ltrim(rtrim($apMaterno));
				//Insertando
				$persona->id = trim($_POST['id']);
				$persona->ci = $aux;
				$persona->nombre    = $nombre;
				$persona->apPaterno = $apPaterno;
				$persona->apMaterno = $apMaterno;
				$persona->telefono  = trim($_POST['telefono']);
				$persona->direccion = trim($_POST['direccion']);
				$persona->update();
				$mensaje = "Datos Actualizados";
			}else{
				$mensaje = "El usuario ya existe";
			}
		}
	}else{
		$a = strstr($key, 'del');
		$b = (substr($a, 0, 3) == 'del')? true:false;
		if($b){
			$worker = new empleado();
			$user = new usuario();
			$worker->id = trim($_POST['id2']);
			$user->idEmpleado = trim($_POST['id2']);
			$worker->delete_logico();
			$user->delete_logico();
			$mensaje = "Datos Eliminados";
		}
	}
	$a = strstr($key, 'res');
  $b = (substr($a, 0, 3)=='res')? true:false;
  if($b){
    $worker = new empleado();
		$user = new usuario();
		$worker->id = trim($_POST['id2']);
		$user->idEmpleado = trim($_POST['id2']);
		$worker->restaurar();
		$user->restaurar();
		$mensaje = "Datos Restaurados";
  }
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800 text-light">Usuarios</h1>
    <a href="registro_usuario.php" class="btn btn-primary">Nuevo</a>
  </div>
  <h4 id="h4_mensaje" class="h3 text-warning"><?= $mensaje?></h4>
  <hr>
  <?php 
    $v1 = empleado::contar_empleados_habilitados(); 
    $v2 = empleado::contar_empleados_deshabilitados();
  ?>
  <?php buscador($v1, $v2);?>
  <br>
  <div class="row">
    <div class="col-lg-12">
      <div class="table-responsive">
        <table class="table table-striped table-bordered" id="mctable">
          <thead class="thead-dark">
            <tr>
              <th>ID</th>
              <th>CI</th>
              <th>NOMBRE COMPLETO</th>
              <th>TELEFONO</th>
              <th>DIRECCIÓN</th>
              <th>ENCARGO</th>
            </tr>
          </thead>
          <!--=====================================opt_Available=====================================-->
          <tbody id="tb_availables">
            <?php 
						$res = empleado::traer_empleados_habilitados();
						$i = 0;
						for($i=0; $i<count($res); $i=$i+1){
							$res2 = persona::traer_todo_persona_empleado_habilitados();
							if($res2[$i]->id == $res[$i]->idPersona){
								?>
            <form id="delete_brand" method="POST">
              <tr>
                <input hidden name="id" <?= "value='{$res2[$i]->id}'" ?>>
                <td id="mycell" class="align-middle">
                  <input class="text-light col-md-12" readonly name="id2" <?= "value='{$res[$i]->id}'" ?>>
                </td>
                <td class="align-middle">
                  <input class="col-md-12 form-control text-light" name="ci"
                    onkeypress="return /[a-z0-9]/i.test(event.key)" type="text"
                    <?= "id='ci{$i}' value={$res2[$i]->ci}"?> disabled />
                </td>
                <td class="align-middle">
                  <input class="mb-1 col-md-12 form-control text-light" name="nombre"
                    onkeypress="return /[a-z ]/i.test(event.key)" type="text"
                    <?= "id='nombre{$i}' value={$res2[$i]->nombre}"?> disabled />
                  <input class="mb-1 col-md-12 form-control text-light" name="apPaterno"
                    onkeypress="return /[a-z ]/i.test(event.key)" type="text"
                    <?= "id='apPaterno{$i}' value={$res2[$i]->apPaterno}"?> disabled />
                  <input class="col-md-12 form-control text-light" name="apMaterno"
                    onkeypress="return /[a-z ]/i.test(event.key)" type="text"
                    <?= "id='apMaterno{$i}'	value={$res2[$i]->apMaterno}"?> disabled />
                </td>
                <td class="align-middle">
                  <input class="col-md-12 form-control text-light" name="telefono"
                    onkeypress="return /[0-9]/i.test(event.key)" type="number"
                    <?= "id='telefono{$i}'	value='{$res2[$i]->telefono}'"?>
                    oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
                    maxlength="8" disabled />
                </td>
                <td class="align-middle">
                  <input class="col-md-12 form-control text-light" name="direccion"
                    onkeypress="return /[a-z .0-9]/i.test(event.key)" type="text"
                    <?= "id='direccion{$i}'	value={$res2[$i]->direccion}"?> disabled />
                </td>
                <td class="align-middle">
                  <input class="col-md-12 form-control text-light" name="direccion"
                    onkeypress="return /[a-z .0-9]/i.test(event.key)" type="text"
                    <?= "id='direccion{$i}' value={$res2[$i]->direccion}"?> disabled />
                </td>
                <td class="align-middle">
                  <input class="btn btn-success" <?= "id='edit{$i}'"?> name="submit" type="button"
                    onclick="enablelisemp(this)" value="Editar">
                </td>
              </tr>
              <tr hidden <?= "id='traux{$i}'"?>>
                <td class="align-middle" colspan="7">
                  <input hidden class="btn btn-info" type="submit" <?= "id='save{$i}'"?> name="guardar" value="Guardar"
                    disabled>
                  <input hidden class="ml-4 btn btn-danger" type="button"
                    <?= "id='bdele{$i}' data-target='#myModal{$i}'"?> value="Eliminar" data-toggle="modal" disabled>
                </td>
                <?php modal($i);?>
              </tr>
            </form>
            <?php
							}
						}
					?>
          </tbody>
          <!--=====================================opt_Unavailable=====================================-->
          <tbody id="tb_unavailables" hidden>
            <?php 
						$res3 = empleado::traer_empleados_deshabilitados();
						$z = 0;
						for($z=0; $z<count($res3); $z=$z+1){
							$res4 = persona::traer_todo_persona_empleado_deshabilitados();
							if($res4[$z]->id == $res3[$z]->idPersona){
								?>
            <form id="delete_brand" method="POST">
              <tr>
                <input hidden name="id" <?= "value='{$res4[$z]->id}'" ?>>
                <td id="mycell" class="align-middle">
                  <input class="text-light col-md-12" readonly name="id2" <?= "value='{$res3[$z]->id}'" ?>>
                </td>
                <td class="align-middle">
                  <input class="col-md-12 form-control text-light" name="ci" type="text" <?= "value={$res4[$z]->ci}"?>
                    disabled />
                </td>
                <td class="align-middle">
                  <input class="mb-1 col-md-12 form-control text-light" name="nombre" type="text"
                    <?= "value={$res4[$z]->nombre}"?> disabled />
                  <input class="mb-1 col-md-12 form-control text-light" name="apPaterno" type="text"
                    <?= "value={$res4[$z]->apPaterno}"?> disabled />
                  <input class="col-md-12 form-control text-light" name="apMaterno" type="text"
                    <?= "value={$res4[$z]->apMaterno}"?> disabled />
                </td>
                <td class="align-middle">
                  <input class="col-md-12 form-control text-light" name="telefono" type="number"
                    <?= "value='{$res4[$z]->telefono}'"?> disabled />
                </td>
                <td class="align-middle">
                  <input class="col-md-12 form-control text-light" name="direccion" type="text"
                    <?= "value={$res4[$z]->direccion}"?> disabled />
                </td>
                <td class="align-middle">
                  <input class="col-md-12 form-control text-light" name="direccion" type="text"
                    <?= "value={$res4[$z]->direccion}"?> disabled />
                </td>
                <?php bttnrestaurar($z);?>
              </tr>
            </form>
            <?php
							}
						}
					?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<!-- /.container-fluid -->

<?php include_once "includes/footer.php"; ?>