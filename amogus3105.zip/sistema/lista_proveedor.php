<?php include_once "includes/header.php"; 
//=================================== ACTUALIZAR ===================================
foreach($_POST as $key=>$value){
	$a = strstr($key, 'gua');
	$b = (substr($a, 0, 3)=='gua')? true:false;
	if($b){
	if(trim($_POST['nombre']) == "")
	{
		$mensaje = "No deje espacios en blanco.";
	}else{
		$aux = strtolower(trim($_POST['nombre']));
		$nombres = proveedor::traer_nombre_proveedores();
		foreach($nombres as  $key=>$datos2){
			if($aux == $datos2->nombre){
				$mensaje = "El proveedor ya existe";
			}
		}
		if($mensaje != "El proveedor ya existe"){
			$provider = new proveedor();
			$nombre = ucwords(strtolower($_POST['nombre']));
			$nombre = preg_replace('/\s+/', ' ', $nombre);
			$nombre = ltrim(rtrim($nombre));
			$provider->id = trim($_POST['id']);
			$provider->nombre = $nombre;
			$provider->direccion = $_POST['direccion'];
			$provider->update();
			$mensaje = "Datos Actualizados";
		}else{
			$mensaje = "El proveedor ya existe";
		}
	}
	}else{
		$a = strstr($key, 'del');
		$b = (substr($a, 0, 3) == 'del')? true:false;
		if($b){
			$provider = new proveedor();
			$provider->id = trim($_POST['id']);
			$provider->delete_logico();
			$mensaje = "Datos Eliminados";
		}
	}
	$a = strstr($key, 'res');
  $b = (substr($a, 0, 3)=='res')? true:false;
  if($b){
    $provider = new proveedor();
    $provider->id = trim($_POST['id']);
    $provider->restaurar();
    $mensaje = "Datos restaurados";
  }
}
?>
<!-- Begin Page Content -->
<div class="container-fluid">
  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800 text-light">Proveedores</h1>
    <a href="registro_proveedor.php" class="btn btn-primary">Nuevo</a>
  </div>
	<h4 id="h4_mensaje" class="h3 text-warning"><?= $mensaje?></h4>
	<hr>
  <?php 
    $v1 = proveedor::contar_proveedores_habilitados(); 
    $v2 = proveedor::contar_proveedores_deshabilitados();
  ?>
  <?php buscador($v1, $v2);?>
  <div class="row">
    <div class="col-lg-12">
      <div class="table-responsive">
        <table class="table table-striped table-bordered" id="mctable">
          <thead class="thead-dark">
            <tr>
              <th>ID</th>
              <th>NOMBRE</th>
              <th>DIRECCION</th>
            </tr>
          </thead>
          <!--=====================================opt_Available=====================================-->
          <tbody id="tb_availables">
            <?php 
						$res = proveedor::traer_proveedores_habilitados();
						$i = 0;
						for($i=0; $i<count($res); $i=$i+1){?>
            <tr>
              <form id="delete_brand" method="POST">
                <td id="mycell">
                  <input class="text-light" readonly name="id" <?= "value='{$res[$i]->id}'" ?>>
                </td>
                <td>
                  <input class="col-md-12 form-control text-light" onkeypress="return /[a-z ]/i.test(event.key)"
                    name="nombre" type="text" <?= "id='nombre{$i}' value='{$res[$i]->nombre}'"?> disabled />
                </td>
                <td>
                  <input class="col-md-12 form-control text-light" onkeypress="return /[a-z .0-9]/i.test(event.key)"
                    name="direccion" type="text" <?= "id='direccion{$i}' value='{$res[$i]->direccion}'"?> disabled />
                </td>
                <?php bttnguardar_borrar($i);?>
                <?php modal($i);?>
                <td>
                  <input class="btn btn-success" <?= "id='edit{$i}'"?> name="submit" type="button"
                    onclick="enablelispro(this)" value="Editar">
                </td>
              </form>
            </tr>
            <?php }
					?>
          </tbody>
          <!--=====================================opt_Unavailable=====================================-->
          <tbody id="tb_unavailables" hidden>
            <?php 
						$res = proveedor::traer_proveedores_deshabilitados();
						$i = 0;
						for($i=0; $i<count($res); $i=$i+1){?>
            <tr>
              <form id="delete_brand" method="POST">
                <td id="mycell">
                  <input class="text-light" readonly name="id" <?= "value='{$res[$i]->id}'" ?>>
                </td>
                <td>
                  <input class="col-md-12 form-control text-light" name="nombre" type="text"
                    <?= "value='{$res[$i]->nombre}'"?> disabled />
                </td>
                <td>
                  <input class="col-md-12 form-control text-light" name="direccion" type="text"
                    <?= "value='{$res[$i]->direccion}'"?> disabled />
                </td>
                <?php bttnrestaurar($i);?>
              </form>
            </tr>
            <?php }
					?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<!-- /.container-fluid -->
<?php include_once "includes/footer.php"; ?>