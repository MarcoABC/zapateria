<?php
    include("conexion.php");
    include("sistema/modelo/database.php");
    include("sistema/modelo/db_object.php");
    include("sistema/control/session.php");
    include("sistema/modelo/persona.php");
    include("sistema/modelo/usuario.php");
    include("sistema/modelo/empleado.php");
    include("sistema/modelo/proveedor.php");
    include("sistema/modelo/cliente.php");
    include("sistema/modelo/categoria.php");
    include("sistema/modelo/marca.php");
    include("sistema/modelo/producto.php");
    
?>
