<?php
    define('DB_HOST' , 'localhost');
    define('DB_USER' , 'silva');
    define('DB_PASS' , 'silva123');
    define('DB_NAME' , '277145');
